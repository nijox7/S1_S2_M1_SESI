#Compte-rendu TP2

##Correction de l'offset
L'instance "iopamp" de "analogLib" ne fonctionne pas, la Netlist n'est pas générée.

##Analyse en fréquence (sans annulation de l'offset)
On a donc une fonction de transfert de type passe bas avec une bande passante de 20MHz et une fréquence de gain unité de environ 4GHz.
On a un gain à faible fréquence de 28 dB.


##Analyse transitoire

###1mV
Décalage de 1.65 - 1.523 = 0.127

0ms:
Vout = 1.5234V
Vin  = 1.65V

1.72ms:
Vout = 1.549V
Vin  = 1.649V
mmmiw
Gain = 26


###100mV

744us:
Vout = 2.62V
Vin  = 1.55V

Gain = |(Vout-1.523)/(Vin-1.65)| = |(2.62 - 1.55) / (1.55 - 1.65)| = 10.7


##Analyse PSS
Harmoniques:
0  Hz  -> 1.6  V
1  kHz -> 1.17 V
2  kHz -> 38   mV
3  kHz -> 236  mV
4  kHz -> 19.5 mV
5  kHz -> 84.7 mV
6  kHz -> 12.2 mV
7  kHz -> 30.9 mV
8  kHz -> 6.7  mV
9  kHz -> 9.2  mV
10 kHz -> 2.7  mV
