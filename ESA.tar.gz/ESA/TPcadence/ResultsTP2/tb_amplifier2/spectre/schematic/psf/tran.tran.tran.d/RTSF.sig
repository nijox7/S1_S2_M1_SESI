0	net1
0	net2
0	V0:p
0	V1:p
0	vdd!
0	I7.net1
0	I7.net3
