0 0 dataAuditErrors
294 0 DEVICE Error: Illegal nmosh device
742 0 Process Modules : PHDNWA850 not available for this process module
746 0 Process Modules : PHDNWB850 not available for this process module
748 0 Version od SBD5 obsolte or missing
756 0 Process Modules : SBD5 not available for this process module
1230 0 ERC Warning : Name of Spiral not identified
1231 0 ERC Warning : INDDEF does not define a correct spiral or is not valid for this process
1248 0 ERC Warning : illegal layer under spiral
1261 0 ERC Warning : Each INDDEF shape must be marked with a single INDDEF text label
1263 0 ERC Warning : multiple text on INDEF
1276 0 Error: MET1 resistors (shorts) must be rectangular
1278 0 Error: Number of MET1 resistor terminals != 2
1290 0 Error: MET2 resistors (shorts) must be rectangular
1292 0 Error: Number of MET2 resistor terminals != 2
1304 0 Error: MET3 resistors (shorts) must be rectangular
1306 0 Error: Number of MET3 resistor terminals != 2
1318 0 Error: MET4 resistors (shorts) must be rectangular
1320 0 Error: Number of MET4 resistor terminals != 2
1330 0 RVIA1 Definition layer: does not open all via conncetion, is shorted
1333 0 RVIA1 Definition layer: truncates via1, device shorted
1334 0 RVIA1 Definition layer: does not define a device
1338 0 RVIA1 Definition layer: over METRES
1345 0 RVIA2 Definition layer: does not open all via conncetion, is shorted
1348 0 RVIA2 Definition layer: truncates via2, device shorted
1349 0 RVIA2 Definition layer : does not define a device
1353 0 RVIA2 Definition layer: over METRES
1361 0 RVIA3 Definition layer: does not open all via conncetion, is shorted
1364 0 RVIA3 Definition layer: truncates via3, device shorted
1365 0 RVIA3 Definition layer : does not define a device
1369 0 RVIA3 Definition layer: over METRES
1469 0 ERROR : POLY1 pin outside poly1
1470 0 ERROR : MET1 pin outside met1
1471 0 ERROR : MET2 pin outside met2
1473 0 ERROR : MET3 pin outside met3
1475 0 ERROR : MET4 pin outside met4
1476 0 ERROR : PAD pin outside pad metal
2805 0 # INFO: C35B4/C35B3 ASSURA LVS DECK (REV9 DATE 28-Apr-11) Last modified 26-May-14 #
3100 0 malformed device NMOSH_device
3101 0 malformed device NMOS18T_device
3102 0 malformed device ESDPD12_device
3103 0 malformed device ESDPD18_device
3104 0 malformed device ESDPD26_device
3105 0 malformed device ESDPD30_device
3106 0 malformed device ESDFDN5_device
3107 0 malformed device ESDGCN5_device
3108 0 malformed device ESDFDP5_device
3109 0 malformed device ESDGCP5_device
3110 0 malformed device RNWELL_device
3111 0 malformed device RDIFFP_device
3112 0 malformed device RPOLY2_PSUB_device
3113 0 malformed device RPOLY2_NTUB_device
3114 0 malformed device RPOLY2P_PSUB_device
3115 0 malformed device RPOLY2P_NTUB_device
3116 0 malformed device RPOLY1_PSUB_device
3117 0 malformed device RPOLY1_NTUB_device
3118 0 malformed device PFUSE_device
3119 0 malformed device LAT2_device
3120 0 malformed device VERT10_device
3121 0 malformed device CPOLY_PSUB_device
3122 0 malformed device CPOLY_NTUB_device
3123 0 malformed device CVAR_device
3124 0 malformed device PROBE_device
3125 0 malformed device NMOSRF_device
3126 0 malformed device PMOSRF_device
3127 0 malformed device CPOLYRF_device
3128 0 malformed device RPOLY2RF_device
3129 0 malformed device SP014S300D_device
3130 0 malformed device SP020S180D_device
3131 0 malformed device SP026S200D_device
3132 0 malformed device SP037S180D_device
3133 0 malformed device SP047S180D_device
3134 0 malformed device SP050S155D_device
3135 0 malformed device SP090S155D_device
3591 0 unstable device for SP090S155D_device_Device_98
3592 0 unpreserved device SP090S155D_device_Device_98
3593 0 unstable device for SP050S155D_device_Device_97
3594 0 unpreserved device SP050S155D_device_Device_97
3595 0 unstable device for SP047S180D_device_Device_96
3596 0 unpreserved device SP047S180D_device_Device_96
3597 0 unstable device for SP037S180D_device_Device_95
3598 0 unpreserved device SP037S180D_device_Device_95
3599 0 unstable device for SP026S200D_device_Device_94
3600 0 unpreserved device SP026S200D_device_Device_94
3601 0 unstable device for SP020S180D_device_Device_93
3602 0 unpreserved device SP020S180D_device_Device_93
3603 0 unstable device for SP014S300D_device_Device_92
3604 0 unpreserved device SP014S300D_device_Device_92
3605 0 unstable device for RPOLYHRF_device_Device_91
3606 0 unpreserved device RPOLYHRF_device_Device_91
3607 0 unstable device for RPOLY2RF_device_RES_90
3608 0 unpreserved device RPOLY2RF_device_RES_90
3609 0 unstable device for CPOLYRF_device_CAP_89
3610 0 unpreserved device CPOLYRF_device_CAP_89
3611 0 unstable device for PMOSRF_device_Device_88
3612 0 unpreserved device PMOSRF_device_Device_88
3613 0 unstable device for NMOSRF_device_Device_87
3614 0 unpreserved device NMOSRF_device_Device_87
3615 0 unstable device for PROBE_device_Device_86
3616 0 unpreserved device PROBE_device_Device_86
3617 0 unstable device for CPMIM_device_Device_85
3618 0 unpreserved device CPMIM_device_Device_85
3619 0 unstable device for CMIM_device_no_cpmim_Device_84
3620 0 unpreserved device CMIM_device_no_cpmim_Device_84
3621 0 unstable device for CVAR_device_Device_83
3622 0 unpreserved device CVAR_device_Device_83
3623 0 unstable device for CPOLY_NTUB_device_CAP_82
3624 0 unpreserved device CPOLY_NTUB_device_CAP_82
3625 0 unstable device for CPOLY_PSUB_device_CAP_81
3626 0 unpreserved device CPOLY_PSUB_device_CAP_81
3627 0 unstable device for VERT10_device_BJT_80
3628 0 unpreserved device VERT10_device_BJT_80
3629 0 unstable device for LAT2_device_Device_79
3630 0 unpreserved device LAT2_device_Device_79
3631 0 unstable device for RVIA3_device_RES_78
3632 0 unpreserved device RVIA3_device_RES_78
3633 0 unstable device for RVIA2_device_RES_77
3634 0 unpreserved device RVIA2_device_RES_77
3635 0 unstable device for RVIA1_device_RES_76
3636 0 unpreserved device RVIA1_device_RES_76
3637 0 unstable device for RMET4_device_RES_75
3638 0 unpreserved device RMET4_device_RES_75
3639 0 unstable device for RMET3_device_RES_74
3640 0 unpreserved device RMET3_device_RES_74
3641 0 unstable device for RMET2_device_RES_73
3642 0 unpreserved device RMET2_device_RES_73
3643 0 unstable device for RMET1_device_RES_72
3644 0 unpreserved device RMET1_device_RES_72
3645 0 unstable device for PFUSE_device_RES_71
3646 0 unpreserved device PFUSE_device_RES_71
3647 0 unstable device for RPOLY1_NTUB_device_RES_70
3648 0 unpreserved device RPOLY1_NTUB_device_RES_70
3649 0 unstable device for RPOLY1_PSUB_device_RES_69
3650 0 unpreserved device RPOLY1_PSUB_device_RES_69
3651 0 unstable device for RPOLYZ_NTUB_device_Device_68
3652 0 unpreserved device RPOLYZ_NTUB_device_Device_68
3653 0 unstable device for RPOLYZ_PSUB_device_Device_67
3654 0 unpreserved device RPOLYZ_PSUB_device_Device_67
3655 0 unstable device for RPOLYH_NTUB_device_Device_66
3656 0 unpreserved device RPOLYH_NTUB_device_Device_66
3657 0 unstable device for RPOLYH_PSUB_device_Device_65
3658 0 unpreserved device RPOLYH_PSUB_device_Device_65
3659 0 unstable device for RPOLY2PH_NTUB_device_Device_64
3660 0 unpreserved device RPOLY2PH_NTUB_device_Device_64
3661 0 unstable device for RPOLY2PH_PSUB_device_Device_63
3662 0 unpreserved device RPOLY2PH_PSUB_device_Device_63
3663 0 unstable device for RPOLY2P_NTUB_device_RES_62
3664 0 unpreserved device RPOLY2P_NTUB_device_RES_62
3665 0 unstable device for RPOLY2P_PSUB_device_RES_61
3666 0 unpreserved device RPOLY2P_PSUB_device_RES_61
3667 0 unstable device for RPOLY2_NTUB_device_RES_60
3668 0 unpreserved device RPOLY2_NTUB_device_RES_60
3669 0 unstable device for RPOLY2_PSUB_device_RES_59
3670 0 unpreserved device RPOLY2_PSUB_device_RES_59
3671 0 unstable device for RDIFFN_device_RES_58
3672 0 unpreserved device RDIFFN_device_RES_58
3673 0 unstable device for RDIFFP_device_RES_57
3674 0 unpreserved device RDIFFP_device_RES_57
3675 0 unstable device for RNWELL_device_RES_56
3676 0 unpreserved device RNWELL_device_RES_56
3677 0 unstable device for ESDGCP5_device_Device_55
3678 0 unpreserved device ESDGCP5_device_Device_55
3679 0 unstable device for ESDFDP5_device_Device_54
3680 0 unpreserved device ESDFDP5_device_Device_54
3681 0 unstable device for ESDGCN5_device_Device_53
3682 0 unpreserved device ESDGCN5_device_Device_53
3683 0 unstable device for ESDFDN5_device_Device_52
3684 0 unpreserved device ESDFDN5_device_Device_52
3685 0 unstable device for ESDPD30_device_Device_51
3686 0 unpreserved device ESDPD30_device_Device_51
3687 0 unstable device for ESDPD26_device_Device_50
3688 0 unpreserved device ESDPD26_device_Device_50
3689 0 unstable device for ESDPD18_device_Device_49
3690 0 unpreserved device ESDPD18_device_Device_49
3691 0 unstable device for ESDPD12_device_Device_48
3692 0 unpreserved device ESDPD12_device_Device_48
3693 0 unstable device for SBD5_device_sbdcon_Device_47
3694 0 unpreserved device SBD5_device_sbdcon_Device_47
3695 0 unstable device for PHDNWB850_device_pad_barc_Device_46
3696 0 unpreserved device PHDNWB850_device_pad_barc_Device_46
3697 0 unstable device for PHDNWA850_device_ntub_Device_45
3698 0 unpreserved device PHDNWA850_device_ntub_Device_45
3699 0 unstable device for ZD2SM24_device_DIODE_44
3700 0 unpreserved device ZD2SM24_device_DIODE_44
3701 0 unstable device for P_NWD_device_Device_43
3702 0 unpreserved device P_NWD_device_Device_43
3703 0 unstable device for NWD_device_DIODE_42
3704 0 unpreserved device NWD_device_DIODE_42
3705 0 unstable device for P_PD_device_Device_41
3706 0 unpreserved device P_PD_device_Device_41
3707 0 unstable device for PD_device_DIODE_40
3708 0 unpreserved device PD_device_DIODE_40
3709 0 unstable device for P_ND_device_Device_39
3710 0 unpreserved device P_ND_device_Device_39
3711 0 unstable device for ND_device_DIODE_38
3712 0 unpreserved device ND_device_DIODE_38
3713 0 unstable device for PMOS30M_device_Device_37
3714 0 unpreserved device PMOS30M_device_Device_37
3715 0 unstable device for PMOSD30M_device_Device_36
3716 0 unpreserved device PMOSD30M_device_Device_36
3717 0 unstable device for NMOS18T_device_Device_35
3718 0 unpreserved device NMOS18T_device_Device_35
3719 0 unstable device for NMOS30M_device_Device_34
3720 0 unpreserved device NMOS30M_device_Device_34
3721 0 unstable device for NMOSMHL_device_Device_33
3722 0 unpreserved device NMOSMHL_device_Device_33
3723 0 unstable device for NMOSHL_device_Device_32
3724 0 unpreserved device NMOSHL_device_Device_32
3725 0 unstable device for NMOSMH_device_Device_31
3726 0 unpreserved device NMOSMH_device_Device_31
3727 0 unstable device for NMOSH_device_Device_30
3728 0 unpreserved device NMOSH_device_Device_30
3729 0 unstable device for PMOSMW_2N_device_Device_29
3730 0 unpreserved device PMOSMW_2N_device_Device_29
3731 0 unstable device for PMOSMW_3N_device_Device_28
3732 0 unpreserved device PMOSMW_3N_device_Device_28
3733 0 unstable device for PMOSMW_4N_device_Device_27
3734 0 unpreserved device PMOSMW_4N_device_Device_27
3735 0 unstable device for PMOSW_2N_device_Device_26
3736 0 unpreserved device PMOSW_2N_device_Device_26
3737 0 unstable device for PMOSW_3N_device_Device_25
3738 0 unpreserved device PMOSW_3N_device_Device_25
3739 0 unstable device for PMOSW_4N_device_Device_24
3740 0 unpreserved device PMOSW_4N_device_Device_24
3741 0 unstable device for NMOSMW_2N_device_Device_23
3742 0 unpreserved device NMOSMW_2N_device_Device_23
3743 0 unstable device for NMOSMW_3N_device_Device_22
3744 0 unpreserved device NMOSMW_3N_device_Device_22
3745 0 unstable device for NMOSMW_4N_device_Device_21
3746 0 unpreserved device NMOSMW_4N_device_Device_21
3747 0 unstable device for NMOSW_2N_device_Device_20
3748 0 unpreserved device NMOSW_2N_device_Device_20
3749 0 unstable device for NMOSW_3N_device_Device_19
3750 0 unpreserved device NMOSW_3N_device_Device_19
3751 0 unstable device for NMOSW_4N_device_Device_18
3752 0 unpreserved device NMOSW_4N_device_Device_18
3753 0 unstable device for PMOSML_WAFFLE_device_Device_17
3754 0 unpreserved device PMOSML_WAFFLE_device_Device_17
3755 0 unstable device for DPMOSM_device_Device_16
3756 0 unpreserved device DPMOSM_device_Device_16
3757 0 unstable device for PMOSML_device_Device_15
3758 0 unpreserved device PMOSML_device_Device_15
3759 0 unstable device for PMOSL_WAFFLE_device_Device_14
3760 0 unpreserved device PMOSL_WAFFLE_device_Device_14
3761 0 unstable device for PMOSL_device_Device_13
3762 0 unpreserved device PMOSL_device_Device_13
3763 0 unstable device for NMOSML_WAFFLE_device_Device_12
3764 0 unpreserved device NMOSML_WAFFLE_device_Device_12
3765 0 unstable device for NMOSML_device_Device_11
3766 0 unpreserved device NMOSML_device_Device_11
3767 0 unstable device for NMOSL_WAFFLE_device_Device_10
3768 0 unpreserved device NMOSL_WAFFLE_device_Device_10
3769 0 unstable device for NMOSL_device_Device_9
3770 0 unpreserved device NMOSL_device_Device_9
3771 0 unstable device for PMOSM_WAFFLE_device_Device_8
3772 0 unpreserved device PMOSM_WAFFLE_device_Device_8
3773 0 unstable device for PMOSM_device_Device_7
3774 0 unpreserved device PMOSM_device_Device_7
3775 0 unstable device for PMOS_WAFFLE_device_Device_6
3776 0 unpreserved device PMOS_WAFFLE_device_Device_6
3777 0 unstable device for PMOS_device_MOS_5
3778 0 unpreserved device PMOS_device_MOS_5
3779 0 unstable device for NMOSM_WAFFLE_device_Device_4
3780 0 unpreserved device NMOSM_WAFFLE_device_Device_4
3781 0 unstable device for NMOSM_device_Device_3
3782 0 unpreserved device NMOSM_device_Device_3
3783 0 unstable device for NMOS_WAFFLE_device_Device_2
3784 0 unpreserved device NMOS_WAFFLE_device_Device_2
3785 0 unstable device for NMOS_device_MOS_1
3786 0 unpreserved device NMOS_device_MOS_1
