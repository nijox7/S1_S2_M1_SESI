*******************************************************************************
****** amplifier3 schematic TPCadence  <vs>  amplifier3 layout TPCadence
*******************************************************************************
                                                                                                                                                                                                                            
Pre-expand Statistics                      
======================                          Original       
Cell/Device                               schematic  layout
(PMOS4) MOS                                       4       8*
(NMOS4) MOS                                       2       2
                                             ------  ------
Total                                             6      10

Reduce Statistics
=================                               Original             Reduced
Cell/Device                               schematic  layout   schematic  layout
(NMOS4) MOS                                       2       2           2       2
(PMOS4) MOS                                       4       8*          4       4

Match Statistics
================                                  Total             Unmatched
Cell/Device                               schematic  layout   schematic  layout
(NMOS4) MOS                                       2       2           0       0
(PMOS4) MOS                                       4       4           0       0
                                             ------  ------      ------  ------
Total                                             6       6           0       0

Match Statistics for Nets                         6       5           1       0

===================================================================[amplifier3]
====== Bad Initial Net Bindings (nets don't match) ============================
===============================================================================

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = (badbind 1)
Schematic Net:  vdd!
S       3   of PMOS4 {D S}
S       3   of PMOS4 B

Layout Net:  vdd!
L      *1   of NMOS4 G
L      *5   of PMOS4 {D S}
L      *1   of PMOS4 G
L      *4   of PMOS4 B

===================================================================[amplifier3]
====== Unmatched Internal Nets ================================================
===============================================================================

S ?vindc


===================================================================[amplifier3]
====== Problem Schematic Nets (no exact match in layout) ======================
===============================================================================
S
S ?vdd!
S       3   of PMOS4 {D S}
S       3   of PMOS4 B
S
S ?vindc
S       1   of NMOS4 G
S       2   of PMOS4 {D S}
S       1   of PMOS4 G
S       1   of PMOS4 B

===================================================================[amplifier3]
====== Problem Layout Nets (no exact match in schematic) ======================
===============================================================================
L
L ?vdd!
L       1   of NMOS4 G
L       5   of PMOS4 {D S}
L       1   of PMOS4 G
L       4   of PMOS4 B

===================================================================[amplifier3]
====== Unmatched or Badly-Matched Schematic Net Details =======================
===============================================================================
S
S ?vindc
S      PMOS4 MP2 G
S      PMOS4 MP2 {D S}
S      PMOS4 MP22 B
S      PMOS4 MP22 {D S}
S      NMOS4 MN11 G
S
S ?vdd!
S      PMOS4 MP11 B
S      PMOS4 MP11 {D S}
S      PMOS4 MP1 B
S      PMOS4 MP1 {D S}
S      PMOS4 MP2 B
S      PMOS4 MP2 {D S}

===================================================================[amplifier3]
====== Unmatched or Badly-Matched Layout Net Details ==========================
===============================================================================
L
L ?vdd!
L      PMOS4 MP1 B
L      PMOS4 MP1 {D S}
L      PMOS4 MP11 B
L      PMOS4 MP11 {D S}
L      PMOS4 MP2 B
L      PMOS4 MP2 {D S}
L      PMOS4 MP2 G
L      PMOS4 MP2 {D S}
L      PMOS4 MP22 B
L      PMOS4 MP22 {D S}
L      NMOS4 MN11 G

===================================================================[amplifier3]
====== Summary of Errors ======================================================
===============================================================================

Schematic  Layout     Error Type
---------  ------     ----------
 1          1         Bad Initial Net Bindings
 1          -         Unmatched Internal Nets

