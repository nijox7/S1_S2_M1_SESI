0 0 dataAuditErrors
105 0 ILL_LAYER_PPLUS_DPL
148 0 ILL_LAYER_HRES
152 0 ILL_LAYER_METCAP
188 0 ILL_ELEMENT_RPOLY2PH
202 0 ILL_ELEMENT_RPOLYZ
306 0 DEVICE Error: Illegal nmosh device
337 0 ILL_LAYER_MIDOX
339 0 ILL_LAYER_LVTDEF
356 0 NMOSW/NMOSMW for waffle trans we expect 1, 2, or 4 s/d conts, diffcont missing
358 0 NMOSW/NMOSMW for waffle trans we expect 1, 2, or 4 s/d conts, too much s/d cont
383 0 PMOSW/PMOSMW for waffle trans we expect 1, 2, or 4 s/d conts, diffcont missing
385 0 PMOSW/PMOSMW for waffle trans we expect 1, 2, or 4 s/d conts, too much s/d cont
557 0 INFO: Test or Probe pad < 60 * 60 U
594 0  INFO : standard pad met3 3 stack
596 0  INFO : standard pad met4 4 stack
601 0  INFO : POA pad met3 stack
603 0  INFO : POA pad met4 stack
776 0 Process Modules : PHDNWA850 not available for this process module
780 0 Process Modules : PHDNWB850 not available for this process module
782 0 Version od SBD5 obsolte or missing
790 0 Process Modules : SBD5 not available for this process module
952 0 ILL_LAYER_PFIMP
1306 0 ERC Warning : Name of Spiral not identified
1307 0 ERC Warning : INDDEF does not define a correct spiral or is not valid for this process
1324 0 ERC Warning : illegal layer under spiral
1337 0 ERC Warning : Each INDDEF shape must be marked with a single INDDEF text label
1339 0 ERC Warning : multiple text on INDEF
1354 0 Error: MET1 resistors (shorts) must be rectangular
1356 0 Error: Number of MET1 resistor terminals != 2
1370 0 Error: MET2 resistors (shorts) must be rectangular
1372 0 Error: Number of MET2 resistor terminals != 2
1386 0 Error: MET3 resistors (shorts) must be rectangular
1388 0 Error: Number of MET3 resistor terminals != 2
1402 0 Error: MET4 resistors (shorts) must be rectangular
1404 0 Error: Number of MET4 resistor terminals != 2
1414 0 RVIA1 Definition layer: does not open all via conncetion, is shorted
1417 0 RVIA1 Definition layer: truncates via1, device shorted
1418 0 RVIA1 Definition layer: does not define a device
1422 0 RVIA1 Definition layer: over METRES
1429 0 RVIA2 Definition layer: does not open all via conncetion, is shorted
1432 0 RVIA2 Definition layer: truncates via2, device shorted
1433 0 RVIA2 Definition layer : does not define a device
1437 0 RVIA2 Definition layer: over METRES
1445 0 RVIA3 Definition layer: does not open all via conncetion, is shorted
1448 0 RVIA3 Definition layer: truncates via3, device shorted
1449 0 RVIA3 Definition layer : does not define a device
1453 0 RVIA3 Definition layer: over METRES
1454 0 rmet1 INFO : rmet1 does not open met1 for drc
1455 0 rmet2 INFO : rmet2 does not open met2 for drc
1456 0 rmet3 INFO : rmet3 does not open met3 for drc
1457 0 rvia1 INFO : rvia1 not opens met1/2 for drc
1458 0 rvia2 INFO : rvia2 not opens met2/3 for drc
1459 0 rmet4 INFO : rmet4 does not open met4 for drc
1460 0 rvia3 INFO : rvia3 not opens met3/4 for drc
1470 0 ERROR : POLY1 pin outside poly1
1471 0 ERROR : MET1 pin outside met1
1472 0 ERROR : MET2 pin outside met2
1474 0 ERROR : MET3 pin outside met3
1476 0 ERROR : MET4 pin outside met4
1477 0 ERROR : PAD pin outside pad metal
1486 0 BAD_SUBSTR_SUBTAP_FLOAT_ERC
1487 0 BAD_SUBSTR_SUBTAP_MULTCONN_ERC
1492 0 BAD_NWELL_WELLTAP_FLOAT_ERC
1493 0 BAD_NWELL_WELLTAP_MULTCONN_ERC
1497 0 INFO: any HVDEF used as isolation
1500 0 NMOSRF_OPEN_GATE
1506 0 PMOSRF_OPEN_GATE
1516 0 NMOSRF Element rule : fixed length = 0.35
1523 0 PMOSRF Element rule : fixed length = 0.35
1526 0 NMOSRF Element Rule : Gate width must be 5.0 U or 10 U
1529 0 PMOSRF Element Rule : Gate width must be 5.0 U or 10 U
1537 0 NMOSRF Element rule stripe width 5 U : max width = 200 U
1539 0 NMOSRF Element rule stripe width 10 U : max width = 200 U
1547 0 PMOSRF Element rule stripe width 5 U : max width = 150 U
1549 0 PMOSRF Element rule stripe width 10 U : max width = 150 U
1552 0 VERT10_P2 Element Rule : Base Ntub Perimeter/4 = 13.8
1556 0 VERT10_P3 Element Rule : Ptap Inside Perimeter/4 = 14.9
1565 0 VERT10_E1 Element Rule : NTUB enclosure of ntap = 0.45
1567 0 LAT2_P1 Element Rule : Emitter Perimeter/4 = 2
1570 0 LAT2_P2 Element Rule : Collector net_pdiff Perimeter/4 = 6.2
1573 0 LAT2_P3 Element Rule : Base Ntub Perimeter/4 = 10.0
1577 0 LAT2_P4 Element Rule : Ptap Inside Perimeter/4 = 11.1
1584 0 LAT2_W1 Element Rule : Lateral Base Width = 1
1593 0 LAT2_E1 Element Rule : NTUB enclosure of ntap = 0.45
1598 0 LAT2_G1 Element Rule : gate of lat2 transistor not connected to VDD or VCC
1600 0 NMOSH_O1/NMOSMH_O1 Element Rule : Gate Overlap of Ntub = 1.6 U
1610 0 NMOSH_S1/NMOSMH_S1 Element Rule : Gate Drain Diff spacing = 2.8
1619 0 NMOSH_E1/NMOSMH_E1 Element Rule : Poly Extension of gate = 0.6 U
1626 0 NMOSH_L1/NMOSMH_L1 Element Rule : Gate Length = 3.0 U
1628 0 NMOSH_X1/NMOSMH_X1 Element Rule : drain angles = 45, 8 vertices
1630 0 NMOSH_X1/NMOSMH_X1 Element Rule : edge length = 0.6 * sqrt(2)
1639 0 CVART_MIN_W Element Rule : cvart min w length = 10.0
1640 0 CVARM_MIN_W Element Rule : cvarm min w length = 10.0
1641 0 CVART_MIN_L Element Rule : cvart min l length = 2.0
1642 0 CVART_MIN_L Element Rule : cvart min l length = 2.0
1649 0 CVAR_W1 Element Rule : Gate unit width = 0.65
1652 0 CVAR_L1 Element Rule : Gate unit length = 6.60
1661 0 CVAR_X1 Element Rule : Gate spacing 1.0
1671 0 CVAR_Y1 Element Rule : Diff spacing 1.6
1672 0 Illegal device : Zener diode must have 0.2 implant ovlp
1673 0 ZD2SM24_O1 Element Rule : must have 0.2 U implant ovlp
1680 0 ZD2SM24_W1 Element Rule : must have 0.40 U n-implant edge length
1681 0 ZD2SM24_W1 Element Rule : must have 0.40 U p-implant edge length
1704 0 PHDNWA850/PHDNWB850 : Illegal layer on photo diode
1707 0 PHDNWA850/PHDNWB850 : Illegal layer on photo diode : met4,via3
1723 0 PHDNWA850/PHDNWB850 : ntub must not enclose any other data
1724 0 PHDNWA850/PHDNWB850 : ntub does not enclose OPTDEF
1725 0 PHDNWA850/PHDNWB850 : OPTDEF does not cover ntub and ndiff totally
1726 0 PHDNWA850/PHDNWB850 : OPTDEF layer outside of ntub and ndiff
1728 0 PHDNWA850/PHDNWB850 : text label for light terminal (P) missing on top level of hierarchie , please add label with terminal name on layer DEVDEF opto for correct extraction
1734 0 PHR001 PHDNWA850/PHDNWB850 : Illegal layer on photo diode OPTDEF  poly1/poly2/met1/met2/met3/met4
1735 0 PHR001 PHDNWA850/PHDNWB850 : Illegal layer on photo diode  OPTDEF : met4
1741 0 BRR001 PHDNWB850 : Illegal layer on photo diode PAD_BARC  poly1/poly2/met1/met2/met3/met4
1742 0 BRR001 PHDNWB850 : Illegal layer on photo diode PAD_BARC : met4
1745 0 PHDNWB850 PAD_BARC : PAD_BARC not rectangle, ATTENTION : data prep problem also, cannot be scaled by 1.5 percent by side if no rect
1747 0 W1BR PHDNWB850 : Minimum PAD_BARC width = 5
1749 0 ILL_LAYER_CHIPEDGE chipedge is only used for testing purposes
1754 0 ATTENTION : Layer SFCDEF should not be used on design data for DRC checking, SFCDEF is a special definition layer for MASK Fabrication
1760 0 INFO PHDNWB850 : single PAD_BARC shape in design,   max allowed width 150 U
1762 0 INFO PHDNWB850 : multiple PAD_BARC shape in design, max allowed width 50 U
1764 0 W2BR :  Maximum PAD_BARC width (1 PAD_BARC shape in design) = 150
1766 0 W3BR :  Maximum PAD_BARC width (multiple PAD_BARC shapes in design) = 50
1769 0 S1BRBR : Minimum PAD_BARC spacing = 7
1771 0 S1BRM1 : Minimum MET1 to PAD_BARC spacing = 1.1
1773 0 S1BRM2 : Minimum MET2 to PAD_BARC spacing = 1.4
1775 0 S1BRM3 : Minimum MET3 to PAD_BARC spacing = 1.6
1777 0 S1BRM4 : Minimum MET4 to PAD_BARC spacing = 2.3
1784 0 PHDNWA850/PHDNWB850 both on same design not allowed, different process option
1786 0 PHDNWA850 : PCOAT not allowed for this process
1787 0 PHDNWB850 : PCOAT not allowed for this process
1789 0 PHDNWA850_W1 : Minimum NTUB size (W and L) = 5
1790 0 PHDNWA850_W2 :  Maximum NTUB size (W and L) = 150
1794 0 PHDNWA850 W1/W2 : PHOTO diode is not square
2058 0 PHDNWA850_S1 : miss substrate ptap Fixed PDIFF to NTUB spacing = 0.4
2068 0 PHDNWA850_E1 : Fixed NTUB enclosure of NDIFF = 0.2
2075 0 PHDNWA850_S1 : Fixed PDIFF to NTUB spacing = 0.4
2078 0 PHDNWB850_W1 : Minimum PAD_BARC size (W and L) = 5
2079 0 PHDNWB850_W2 : Maximum PAD_BARC size (W and L) = 150
2083 0 PHDNWB850 W1/W2 : PHOTO diode is not square
2346 0 PHDNWB850_S1: miss substrate ptap Fixed PDIFF to NTUB spacing = 0.4
2356 0 PHDNWB850_E1 : Fixed NTUB enclosure of NDIFF = 0.2
2363 0 PHDNWB850_S1 : Fixed PDIFF to NTUB spacing = 0.4
2373 0 PHDNWB850_E2 : Fixed NDIFF enclosure of PAD_BARC = 0.5
2447 0 PHDNWB850_E2 : Fixed NDIFF enclosure of PAD_BARC = 0.5
2455 0 PHDNWB850_S2 : Fixed MET1 to PAD_BARC spacing = 1.2
2459 0 V1R003 : VIA1 overlapping SBDCON is not allowed
2461 0 S1COV1 : Minimum VIA1 spacing to SBDCON
2462 0 SBD5 DIODE : multiple SBDCON
2466 0 SDB5 DIODE : bad sbdcon
2473 0 SBD5_W DIODE fixed SBDCON width 0.4
2475 0 SBD5_W_L1 DIODE : SBDCON must have fixed L = 12 and fixed W = 0.4
2484 0 SBD5_X1 DIFF enclosure of SBDCON 0.3
2491 0 SBD5_X2 DIFF spacing 0.8
2498 0 SBD5_X3 DIFF spacing 0.55
2501 0 SBD5_X4 minimum NTUB ovlp ndiff 1.0
2505 0 SBD5_CATHODE_X5 SBD5_X5 minimum MET1 ovlp CONT 0.3
2509 0 SBD5_ANODE_X5 SBD5_X5 minimum MET1 ovlp CONT 0.3
2518 0 SBD5 DIODE : Illegal layer on Schottky diode
2536 0 SBD5 INFO : Orientation horizontal
2543 0 SBD5 INFO : Orientation vertical
2546 0 SBD5_R1 : Multiple SBD5 in a shared NTUB shape must have the same orientation
2549 0 PFR001 : DEVDEF_pfuse outside IPDEF is not allowed
2550 0 Error : RESDEF over DEVDEF_pfuse not allowed
2557 0 ERC Warning : This poly2 over HRES layer is high ohmic, but shorted for LVS
2558 0 CPMIM not supported over RFDEF
2564 0 CPMIM error : cpmim must be totally inside POLY2
2573 0 E1P2MC : Fixed poly2 enclosure of metcap 1.15
2575 0 CPMIM_R1 : CPMIM overlapping MET1 is not allowed
2588 0 CPMIM_R2 Element check: met3 metcap/poly1 plates of CPMIM not connected correctly
2589 0 CPMIM_R3 Element check: met2/poly2 plates of CPMIM not connected correctly
2591 0 W1PW : Minimum FIDEF width = 1.7
2594 0  S1PWPW : Minimum FIDEF spacing = 1
2597 0 S1NWPW : Minimum FIDEF to NTUB spacing = 6.5
2600 0 S1HVHV Minimum HVDEF spacing = 0.1
2602 0 HVR001 Each HVDEF shape must be marked with a single HVDEF text label
2604 0 INFO : multiple text on HVDEF
2605 0 INFO: NMOS18T HVDEF
2606 0 INFO: NMOS30M HVDEF
2609 0 HVR001 : Version of NMOS18T_REV1 obsolete
2610 0 HVR001 : Version of NMOS30M_REV2 obsolete
2611 0 HVR001 : No HVDEF on NMOS18T
2612 0 HVR001 : No HVDEF on NMOS30M
2613 0 HVR001 : Version of NMOS18T obsolete or missing
2614 0 HVR001 : Version of NMOS30M obsolete or missing
2615 0 HVR001 : HVDEF has illegal name on NMOS18T
2616 0 HVR001 : HVDEF has illegal name on NMOS30M
2641 0 NMOS18T/NMOS30M L Element Rule : Min gate length = 0.5 U
2642 0 NMOS18T/M W2 Element Rule : Min gate width/2 = 5 U
2655 0 NMOS30M X4 Element Rule : drain ndiff to source diff spacing (field plate) 2.0 U fixed
2662 0 NMOS18T X4 Element Rule : drain ndiff to source diff spacing (field plate) 1.8 U fixed
2671 0 NMOS30M X1 Element Rule : poly1 to drain diff spacing 0.4 U fixed
2678 0 NMOS18T X1 Element Rule : poly1 to drain diff spacing 0.35 U fixed
2688 0 NMOS30M/NMOS18T Element Rule X3 : ntub ovlp drain diff 1.85 U fixed
2697 0 NMOS30M Element Rule X5 : source diff ovlp of fidef = 1.5
2704 0 NMOS18T Element Rule X5 : source diff ovlp of fidef = 1.8
2711 0 NMOS30M/T Element Rule Y1 : poly1 to drain diff spacing 1 U fixed
2729 0 NMOS30M/T Element Rule Y2 : ntub stripe ovlp of drain diff = 3 
2735 0 NMOS18T/M Y3 Element Rule : poly width of gate connect = 2 U
2742 0 NMOS30M/T Element Rule Y4 : fidef ovlp of ntub = 2.8 U
2743 0 NMOS18T/M  Element Rule : nmos30m/nmos18t must have 1 ntub shape
2749 0 NMOS30M/T Element Rule Y5 : fidef to bulk pdiff spacing = 1.2 
2751 0 NMOS18T/M Y8 Element Rule : poly must be angled
2753 0 NMOS18T/M Y8 Element Rule : 45 degree poly must have length 0.7
2755 0 NMOS18T/M Y9 Element Rule : 45 degree poly must have length 0.7
2757 0 NMOS18T/M Y11 Element Rule : fidef must be angled
2759 0 NMOS18T/M Y11 Element Rule : fidef edge length = 0.75 * sqrt(2)
2763 0 NMOS18T/M Element Rule Y10 : fidef vertex to sdiff spacing = 1.75
2765 0 W2PW : Minimum PFIMP width = 0.8
2768 0  S2PWPW : Minimum PFIMP spacing = 1
2770 0 PWR002 : (PFIMP and not (HVDEF or SFCDEF)) is not allowed
2771 0 INFO : PMOSD30M HVDEF
2782 0 HVR001 : No HVDEF on PMOSD30M
2783 0 HVR001 : Version of PMOSD30M obsolete or missing
2784 0 HVR001 : Version of PMOSD30M is REV1 and obsolete, use rev2 
2785 0 HVR001 : HVDEF has illegal name on PMOSD30M
2804 0 PMOSD30M : Minimum CHANNEL length = 0.6
2805 0 PMOSD30M : Minimum CHANNEL width / N = 6.4
2818 0 PMOSD30M X1 Element Rule : POLY1 to DRAIN-PDIFF spacing = 0.3
2825 0 PMOSD30M Element Rule Y1 : POLY1 to DRAIN-PDIFF spacing = 0.3
2832 0 PMOSD30M X2 Element Rule : DRAIN-PDIFF to SOURCE-DIFF spacing (field plate) = 2.4
2839 0 PMOSD30M_X3 Element Rule : PFIMP overlap of SOURCE-DIFF = 0.6
2842 0 PMOSD30M_X4 Element Rule : Minimum NTUB enclosure of BULK-NDIFF = 0.8
2844 0 PMOSD30M_X5 Element Rule : NTUB to SUBSTRATE-PDIFF spacing = 2.4
3156 0 PMOSD30M_X5 Element Rule : miss substrate ptap Fixed PDIFF to NTUB spacing = 2.4
3172 0 PMOSD30M Element Rule X5  : bad layer between ntub and subtap
3181 0 PMOSD30M Element Rule X5 INFO : nofill should be drawn between ntub and subtap to avoid poly1 filling in intrinsic substrate
3189 0 PMOSD30M Element Rule X6 : NPLUS to PGATE spacing = 0.3
3198 0 PMOSD30M Element Rule Y2 : PFIMP enclosure of DRAIN-PDIFF = 2
3205 0 PMOSD30M Element Rule Y3 : BULK-NDIFF to DRAIN-PDIFF spacing = 4.25
3211 0 PMOSD30M Element Rule Y4 : POLY1 width of gate connection = 1.75
3213 0 PMOSD30M Element Rule Y5 : illegal vertices POLY1 45-deg corner (outside) = 0.55
3215 0 PMOSD30M Element Rule Y5 : POLY1 45-deg corner (outside) = 0.55
3219 0 PMOSD30M Element Rule Y5 : poly hole must not be angled 
3224 0 PMOSD30M Element Rule Y8 : Minimum PPLUS enclosure of PDIFFCON = 0.2
3238 0 PMOSD30M_R2 Element Rule R2 : SOURCE-PDIFF cannot be butted with BULK-NDIFF ring
3239 0 PMOSD30M_R2 Element Rule R2 : SOURCE-PDIFF cannot be butted with BULK-NDIFF ring
3245 0 PMOSD30M Element Rule Y7 : Minimum PDIFF enclosure of PDIFFCON = 0.2
3247 0 PMOSD30M Element Rule Y7: fixed size of butting ndiff square 0.9 x 0.9
3250 0 PMOSD30M INFO : min spacing of butting ndiff to ndiff 1.6 U
3269 0 PMOSD30M_R1: Bulk and source must be connected with met1 (check1)
3285 0 PMOSD30M_R1: Bulk and source must be connected with met1 (check2)
3304 0 PMOSD30M_R1: Bulk and source must be connected with met1 also for single device
3315 0 PMOSD30M_HVR003_sources_must_be_connected_together
3321 0 PMOSD30M Element Rule : pfimp must be rectangle
3322 0  PMOSD30M : this device not supported for any pad over active application
3323 0 INFO : PMOS30M HVDEF
3334 0 HVR001 : No HVDEF on PMOS30M
3335 0 HVR001 : Version of PMOS30M obsolete or missing
3336 0 HVR001 : HVDEF has illegal name on PMOS30M
3355 0 PMOS30M : _PMOS30M_L_
3356 0 PMOS30M : _PMOS30M_W2_
3369 0 PMOS30M X1 Element Rule : _PMOS30M_X1_
3376 0 PMOS30M Element Rule Y1 : _PMOS30M_Y1_
3383 0 PMOS30M X2 Element Rule : _PMOS30M_X2_
3390 0 PMOS30M_X3 Element Rule : _PMOS30M_X3_
3393 0 PMOS30M_X4 Element Rule : _PMOS30M_X4_
3395 0 PMOS30M_X5 Element Rule : _PMOS30M_X5_
3707 0 PMOS30M_X5 Element Rule : miss substrate ptap Fixed PDIFF to NTUB spacing = 2.4
3723 0 PMOS30M Element Rule X5  : bad layer between ntub and subtap
3731 0 PMOS30M Element Rule X5 INFO : nofill should be drawn between ntub and subtap to avoid poly1 filling in intrinsic substrate
3740 0 PMOS30M Element Rule Y2 : _PMOS30M_Y2_
3747 0 PMOS30M Element Rule Y3 : _PMOS30M_Y3_
3753 0 PMOS30M Element Rule Y4 : _PMOS30M_Y4_
3755 0 PMOS30M Element Rule Y5 : illegal vertices _PMOS30M_Y5_
3757 0 PMOS30M Element Rule Y5 : _PMOS30M_Y5_
3761 0 PMOS30M Element Rule Y5 : poly hole must not be angled 
3772 0 PMOS30M_HVR003_sources_must_be_connected_together
3778 0 PMOS30M Element Rule : pfimp must be rectangle
3779 0  PMOS30M : this device not supported for any pad over active application
3781 0 INFO: ESDPD12 HVDEF
3783 0 HVR001 : Version of ESDPD12 obsolete or missing
3784 0 HVR001 : HVDEF has illegal name on ESDPD12
3786 0 INFO: ESDPD26 HVDEF
3788 0 HVR001 : Version of ESDPD26 obsolete or missing
3789 0 HVR001 : HVDEF has illegal name on ESDPD26
3791 0 INFO: ESDPD18 HVDEF
3793 0 HVR001 : Version of ESDPD18 obsolete or missing
3794 0 HVR001 : HVDEF has illegal name on ESDPD18
3796 0 INFO: ESDPD30 HVDEF
3798 0 HVR001 : Version of ESDPD30 obsolete or missing
3799 0 HVR001 : HVDEF has illegal name on ESDPD30
3801 0 INFO: ESDGCN5 HVDEF
3803 0 HVR001 : Version of ESDGCN5 obsolete or missing
3804 0 HVR001 : HVDEF has illegal name on ESDGCN5
3806 0 INFO: ESDGCP5 HVDEF
3808 0 HVR001 : Version of ESDGCP5 obsolete or missing
3809 0 HVR001 : HVDEF has illegal name on ESDGCP5
3811 0 INFO: ESDFDP5 HVDEF
3813 0 HVR001 : Version of ESDFDP5 obsolete or missing
3814 0 HVR001 : HVDEF has illegal name on ESDFDP5
3816 0 INFO: ESDFDN5 HVDEF
3818 0 HVR001 : Version of ESDFDN5 obsolete or missing
3819 0 HVR001 : HVDEF has illegal name on ESDFDN5
3821 0 HVR001 : HVDEF does not enclose a valid HV-device, bad HVDEF or bad device
3840 0 ESDPD12_L Element Rule : _ESDPD12_L_
3841 0 ESDPD12_W1 Element Rule : _ESDPD12_W1_
3842 0 ESDPD12_W2 Element Rule : _ESDPD12_W2_
3851 0 ESDPD12_X2 Element Rule : _ESDPD12_X2_
3860 0 ESDPD12_Y2 Element Rule : _ESDPD12_Y2_
3867 0 ESDPD12_X3 Element Rule : _ESDPD12_X3_
3874 0 ESDPD12_Y3 Element Rule : _ESDPD12_Y3_
3881 0 ESDPD12_X4 Element Rule : _ESDPD12_X4_
3896 0 ESDPD18_L Element Rule : CATHODE-NTUB length = 1.7
3897 0 ESDPD18_W1 Element Rule : Minimum CATHODE-NTUB width = 10
3898 0 ESDPD18_W2 Element Rule : Maximum CATHODE-NTUB width = 10000
3907 0 ESDPD18_X2 Element Rule : NTUB enclosure of NDIFF = 0.5
3916 0 ESDPD18_Y2 Element Rule : NTUB enclosure of NDIFF = 1.5
3923 0 ESDPD18_X3 Element Rule : PDIFF to NTUB spacing = 0.5
3930 0 ESDPD18_Y3 Element Rule : PDIFF to NTUB spacing = 2
3937 0 ESDPD18_X4 Element Rule : PDIFF width = 0.7
3940 0 ESDPD18_X5 Element Rule : Minimum CATHODE-MET1 width = 1.6
3957 0 ESDPD26_L Element Rule : CATHODE-NTUB length = 2.1
3958 0 ESDPD26_W1 Element Rule : Minimum CATHODE-NTUB width = 10
3959 0 ESDPD26_W2 Element Rule : Maximum CATHODE-NTUB width = 10000
3968 0 ESDPD26_X2 Element Rule : NTUB enclosure of NDIFF = 0.7
3977 0 ESDPD26_Y2 Element Rule : NTUB enclosure of NDIFF = 1.7
3984 0 ESDPD26_X3 Element Rule : PDIFF to NTUB spacing = 1
3991 0 ESDPD26_Y3 Element Rule : PDIFF to NTUB spacing = 2
3998 0 ESDPD26_X4 Element Rule : PDIFF width = 0.7
4001 0 ESDPD26_X5 Element Rule : Minimum CATHODE-MET1 width = 1.9
4018 0 ESDPD30_L Element Rule : CATHODE-NTUB length = 2.3
4019 0 ESDPD30_W1 Element Rule : Minimum CATHODE-NTUB width = 10
4020 0 ESDPD30_W2 Element Rule : Maximum CATHODE-NTUB width = 10000
4029 0 ESDPD30_X2 Element Rule : NTUB enclosure of NDIFF = 0.8
4038 0 ESDPD30_Y2 Element Rule : NTUB enclosure of NDIFF = 1.8
4045 0 ESDPD30_X3 Element Rule : PDIFF to NTUB spacing = 1.5
4052 0 ESDPD30_Y3 Element Rule : PDIFF to NTUB spacing = 2
4059 0 ESDPD30_X4 Element Rule : PDIFF width = 0.7
4062 0 ESDPD30_X5 Element Rule : Minimum CATHODE-MET1 width = 1.9
4077 0 ESDFDP5_L Element Rule : ANODE-PDIFF length = 0.7
4078 0 ESDFDP5_W1 Element Rule : Minimum ANODE-PDIFF width = 10
4079 0 ESDFDP5_W2 Element Rule : Maximum ANODE-PDIFF width = 200
4086 0 ESDFDP5_X2 Element Rule : PDIFF to NDIFF spacing = 0.7
4093 0 ESDFDP5_X3 Element Rule : NDIFF width = 0.7
4106 0 ESDFDN5_L Element Rule : CATHODE-NDIFF length = 0.7
4107 0 ESDFDN5_W1 Element Rule : Minimum CATHODE-NDIFF width = 10
4108 0 ESDFDN5_W2 Element Rule : Maximum CATHODE-NDIFF width = 200
4115 0 ESDFDN5_X2 Element Rule : NDIFF to PDIFF spacing = 0.7
4122 0 ESDFDN5_X3 Element Rule : PDIFF width = 0.7
4148 0 ESDGCN5_L Element Rule : CATHODE-NDIFF length = 0.7
4149 0 ESDGCN5_W1 Element Rule : Minimum CATHODE-NDIFF width = 0.7
4150 0 ESDGCN5_W2 Element Rule : Maximum CATHODE-NDIFF width = 100
4157 0 ESDGCN5_X2 Element Rule : NDIFF to PDIFF spacing = 0.7
4164 0 ESDGCN5_X3 Element Rule : PDIFF width = 0.7
4192 0 ESDGCP5_L Element Rule : ANODE-PDIFF length = 0.7
4193 0 ESDGCP5_W1 Element Rule : Minimum ANODE-PDIFF width = 0.7
4194 0 ESDGCP5_W2 Element Rule : Maximum ANODE-PDIFF width = 100
4201 0 ESDGCP5_X2 Element Rule : PDIFF to NDIFF spacing = 0.7
4208 0 ESDGCP5_X3 Element Rule : NDIFF width = 0.7
4216 0 MOSW : Waffle trans : cannot mix different size of holes over same diff
4218 0 MOSW : Waffle trans hole : poly hole size incorrect
4224 0 MOSW : Waffle trans gate : these gates cannot be identified correctly due to size of poly hole and are discarded from LVS
4232 0 NMOSW : Waffle trans : shorted device nmosw
4240 0 NMOSMW : Waffle trans : shorted device nmosmw
4248 0 PMOSW : Waffle trans : shorted device pmosw
4256 0 PMOSMW : Waffle trans : shorted device pmosmw
4276 0 NMOSW : Waffle trans : s/d of waffle trans not connected to other sd over same waffle diff, Inactive Unit found, causes encreasing current flow in neighbouring devices
4296 0 NMOSMW : Waffle trans : s/d of waffle trans not connected to other sd over same waffle diff, Inactive Unit found, causes encreasing current flow in neighbouring devices
4316 0 PMOSW : Waffle trans : s/d of waffle trans not connected to other sd over same waffle diff, Inactive Unit found, causes encreasing current flow in neighbouring devices
4336 0 PMOSMW : Waffle trans : s/d of waffle trans not connected to other sd over same waffle diff, Inactive Unit found, causes encreasing current flow in neighbouring devices
4339 0  NMOSW for waffle trans we expect 1, 2, or 4 s/d conts
4342 0  NMOSMW for waffle trans we expect 1, 2, or 4 s/d conts
4353 0 NMOSW_W : Waffle trans : fixed channel length 4 = 2.8 sqrt(2)
4354 0 NMOSW_L1 : Waffle trans : min channel length 0.5 = 0.35 sqrt(2)
4355 0 NMOSW_L2 : Waffle trans : max channel length 3.0 = 2.1 sqrt(2)
4356 0 NMOSMW_W : Waffle trans : fixed channel length 4 = 2.8 sqrt(2)
4357 0 NMOSMW_L1 : Waffle trans : min channel length 0.5 = 0.35 sqrt(2)
4358 0 NMOSMW_L2 : Waffle trans : max channel length 3.0 = 2.1 sqrt(2)
4378 0 NMOSW_S1 : Waffle trans : fixed diffcon to gate spacing 1.2 0.85 * sqrt(2)
4398 0 NMOSMW_S1 : Waffle trans : fixed diffcon to gate spacing 1.2 0.85 * sqrt(2)
4401 0  PMOSW for waffle trans we expect 1, 2, or 4 s/d conts
4404 0  PMOSMW for waffle trans we expect 1, 2, or 4 s/d conts
4415 0 PMOSW_W : Waffle trans : fixed channel length 4 = 2.8 sqrt(2)
4416 0 PMOSW_L1 : Waffle trans : min channel length 0.5 = 0.35 sqrt(2)
4417 0 PMOSW_L2 : Waffle trans : max channel length 3.0 = 2.1 sqrt(2)
4418 0 PMOSMW_W : Waffle trans : fixed channel length 4 = 2.8 sqrt(2)
4419 0 PMOSMW_L1 : Waffle trans : min channel length 0.5 = 0.35 sqrt(2)
4420 0 PMOSMW_L2 : Waffle trans : max channel length 3.0 = 2.1 sqrt(2)
4440 0 PMOSW_S1 : Waffle trans : fixed diffcon to gate spacing 1.2 0.85 * sqrt(2)
4460 0 PMOSMW_S1 : Waffle trans : fixed diffcon to gate spacing 1.2 0.85 * sqrt(2)
4461 0 ILL_LAYER_LVTA
4462 0 ILL_LAYER_LVPTUB
4465 0 ILL_ELEMENT_RPOLYH_RPOLYZ
4468 0 ILL_ELEMENT_RPOLY2P_RPOLY2PH
4469 0 NTUB net layer must not be used in layout view
4470 0 POLY1 net layer must not be used in layout view
4471 0 POLY2 net layer must not be used in layout view
4472 0 CONT net layer must not be used in layout view
4473 0 MET1 net layer must not be used in layout view
4474 0 VIA1 net layer must not be used in layout view
4475 0 MET2 net layer must not be used in layout view
4476 0 VIA2 net layer must not be used in layout view
4477 0 MET3 net layer must not be used in layout view
4478 0 VIA3 net layer must not be used in layout view
4479 0 MET4 net layer must not be used in layout view
4481 0 Warning: No MET4 on MET4 Pin
4483 0 Warning: No POLY1 on POLY1 Pin
4485 0 Warning: No MET1 on MET1 Pin
4487 0 Warning: No MET2 on MET2 Pin
4489 0 Warning: No MET3 on MET3 Pin
4498 0 REC002 REC002 NTUB not multiple 45 degrees REC002
4499 0 REC002 REC002 DIFF not multiple 45 degrees REC002
4500 0 REC002 REC002 MIDOX not multiple 45 degrees REC002
4501 0 REC002 REC002 POLY1 not multiple 45 degrees REC002
4502 0 REC002 REC002 NPLUS not multiple 45 degrees REC002
4503 0 REC002 REC002 PPLUS not multiple 45 degrees REC002
4504 0 REC002 REC002 HRES not multiple 45 degrees REC002
4505 0 REC002 REC002 CONT not multiple 45 degrees REC002
4506 0 REC002 REC002 MET1 not multiple 45 degrees REC002
4507 0 REC002 REC002 VIA1 not multiple 45 degrees REC002
4508 0 REC002 REC002 MET2 not multiple 45 degrees REC002
4509 0 REC002 REC002 VIA2 not multiple 45 degrees REC002
4510 0 REC002 REC002 MET3 not multiple 45 degrees REC002
4511 0 REC002 REC002 VIA3 not multiple 45 degrees REC002
4512 0 REC002 REC002 MET4 not multiple 45 degrees REC002
4513 0 REC002 REC002 PAD not multiple 45 degrees REC002
4524 0 INFO: hot nwell
4527 0 NW_W_1 Minimum NTUB width = 1.7
4529 0 NW_W_2 Minimum HOT_NTUB width = 3
4543 0 NW_S_1 Minimum spacing of NTUB with different potential = 3
4546 0 NW_S_2 Minimum spacing of NTUB with same potential = 1
4548 0 NW_S_2 Minimum spacing of NTUB with same potential = 1 notch
4561 0 OD_W_1 Minimum DIFF width to define the width of NMOS/PMOS = 0.4 ngate
4570 0 OD_W_1 Minimum DIFF width to define the width of NMOS/PMOS = 0.4 pgate
4572 0 OD_W_2 Minimum DIFF width for interconnection (NDIFF or PDIFF) = 0.3
4575 0 OD_S_1 Minimum DIFF spacing = 0.6
4577 0 OD_S_1 Minimum DIFF spacing = 0.6 notch 
4583 0 OD_C_1 Minimum NTUB enclosure of NDIFF = 0.2
4587 0 OD_C_2 Minimum NDIFF to NTUB spacing = 1.2
4602 0 OD_C_3 Minimum NDIFF to HOT_NTUB spacing (no PTAP in between) = 2.6
4606 0 OD_C_4 Minimum NTUB enclosure of PDIFF = 1.2
4608 0 OD_C_5 Minimum PDIFF to NTUB spacing = 0.2
4611 0 OD_C_6a Minimum PDIFF to NGATE spacing = 0.45
4616 0 OD_C_6b Minimum NDIFF to PGATE spacing = 0.45
4624 0 OD_S_2B Minimum NDIFF to non-butting PDIFF spacing = 0.6
4625 0 INFO : nplus pplus overlap
4628 0 INFO: DIFF missing nplus/pplus
4630 0 W1XM Minimum MIDOX width = 0.6
4638 0 OD2_E_1 Minimum MIDOX enclosure of DIFF = 0.6
4641 0 OD2_S_1 Minimum MIDOX spacing = 0.6
4643 0 OD2_C_1 Minimum MIDOX to DIFF spacing = 0.6
4645 0 BAD1XM MIDOX outside GATE is not allowed
4657 0 PO_W_1a Minimum GATE length of PMOS = 0.35
4659 0 PO_W_1b Minimum GATE length of PMOSM = 0.5
4661 0 PO_W_2a Minimum GATE length of NMOS = 0.35
4663 0 PO_W_2b Minimum GATE length of NMOSM = 0.5
4666 0 PO_W_3 Minimum POLY1 width for interconnect = 0.35
4669 0 PO_S_1 Minimum POLY1 spacing = 0.45 
4671 0 PO_S_1 Minimum POLY1 spacing = 0.45 notch
4673 0 PO_C_1 Minimum POLY1 to DIFF spacing = 0.2
4682 0 PO_C_2 Minimum DIFF extension of GATE = 0.5
4685 0 PO_O_1 Minimum POLY1 extension of GATE = 0.4
4687 0 PO_R_1 Minimum density of POLY1 area [%] = 14
4689 0 PO2_W_1 Minimum CPOLY width = 0.8
4692 0 PO2_S_1 Minimum CPOLY spacing = 0.65
4695 0 PO2_E_1 Minimum POLY1 enclosure of CPOLY = 1
4698 0 PO2_E_2 Minimum CPOLY enclosure of POLY2CON = 0.6
4700 0 PO2_C_1 Minimum POLY1CON to CPOLY spacing = 1.2
4702 0 PO2_W_2 Minimum POLY2 width = 0.65
4705 0 PO2_S_2 Minimum POLY2 spacing = 0.5
4707 0 PO2_S_2 Minimum POLY2 spacing = 0.5 notch
4709 0 PO2_S_2 Minimum POLY2 spacing = 0.5 notch
4711 0 PO2_S_2 Minimum POLY2 spacing = 0.5 notch
4713 0 PO2_W_3 Minimum RPOLYH width = 0.8
4716 0 PO2_S_3 Minimum RPOLYH spacing = 0.75
4718 0 PO2_S_3 Minimum RPOLYH spacing = 0.75 notch
4720 0 PO2_C_2 Minimum DIFF to POLY2 spacing = 0.2
4722 0 PO2_C_3 Minimum POLY1 to POLY2 spacing = 0.65
4727 0 PO2_E_3 Minimum POLY2 enclosure of POLY2CON = 0.25
4728 0 PO2_R_1 POLY2 on DIFF is not allowed
4730 0 PP_W_1 Minimum PPLUS width = 0.6
4733 0 PP_S_1 Minimum PPLUS spacing = 0.6
4735 0 PP_C_1 Minimum PPLUS to DIFF spacing = 0.35
4737 0 PP_C_2 Minimum PPLUS to NGATE spacing = 0.45
4743 0 PP_C_3 Minimum PPLUS extension of PGATE = 0.45
4745 0 PP_O_1  Minimum overlap of PPLUS and DIFF = 0.45
4748 0 PP_E_1 Minimum PPLUS extension of DIFF = 0.25
4755 0 PP_C_5 NP_C_5 NPC5/PPC5  Minimum PPLUS to NPLUS spacing on POLY1 = 0.25
4757 0 PP_C_6 Minimum PPLUS to NPLUS spacing on DIFF with same potential = 0
4759 0 NP_W_1 Minimum NPLUS width = 0.6
4762 0 NP_S_1 Minimum NPLUS spacing = 0.6
4764 0 NP_C_1 Minimum NPLUS to DIFF spacing = 0.35
4768 0 NP_C_2 Minimum NPLUS to PGATE spacing = 0.45
4771 0 NP_C_3 Minimum NPLUS extension of NGATE = 0.45
4773 0 NP_O_1  Minimum overlap of NPLUS and DIFF = 0.45
4776 0 NP_E_1 Minimum NPLUS extension of DIFF = 0.25
4778 0 NP_C_6 Minimum NPLUS to PPLUS spacing on DIFF with same potential = 0
4786 0 CO_W_1 Fixed CONT width = 0.4
4789 0 CO_S_1 Minimum CONT spacing = 0.4
4791 0 CO_C_1 Minimum DIFFCON to GATE spacing = 0.3
4793 0 CO_C_2  Minimum POLY1CON to DIFF spacing = 0.4
4796 0 CO_E_1 Minimum DIFF enclosure of DIFFCON = 0.15
4799 0 CO_E_2 Minimum POLY1 enclosure of POLY1CON = 0.2
4804 0 CO_E_3 Minimum PPLUS enclosure of PDIFFCON = 0.25
4807 0 CO_E_4  Minimum NPLUS enclosure of NDIFFCON = 0.25
4808 0 CO_R_1 POLY1CON on DIFF is not allowed
4811 0 CO_R_2 Butted CONT is not allowed
4812 0 R0_1_CT CONT without DIFF or POLY1 or POLY2 is not allowed
4813 0 ERC Warning: CONT without metal1
4814 0 ERC Warning: CONT without diff or poly
4816 0 M1_W_1 Minimum MET1 width = 0.5
4819 0 M1_S_1  Minimum MET1 spacing = 0.45
4862 0 M1_S_2 Minimum MET1 to WIDE_MET1 spacing = 0.8 wide wide
4864 0 M1_S_2 Minimum MET1 to WIDE_MET1 spacing = 0.8 wide small
4869 0 M1_E_1 Minimum MET1 enclosure of CONT = 0.15
4871 0 M1_R_1 Minimum density of MET1 area [%] = 30
4873 0 VIA1_W_1 Fixed VIA1 width = 0.5
4876 0 VIA1_S_1 Minimum VIA1 spacing = 0.45
4881 0 VIA1_E_1 Minimum MET1 enclosure of VIA1 = 0.2
4882 0 R01V1 VIA1 without MET1 is not allowed
4883 0 ERC Warning: Via1 missing metal1
4885 0 M2_W_1 Minimum MET2 width = 0.6
4888 0 M2_S_1 Minimum MET2 spacing = 0.5
4931 0 M2_S_2 Minimum MET2 to WIDE_MET2 spacing = 0.8 wide wide
4933 0 M2_S_2 Minimum MET2 to WIDE_MET2 spacing = 0.8 wide small
4938 0 M2_E_1 Minimum MET2 enclosure of VIA1 = 0.15
4940 0 M2_R_1 Minimum density of MET2 area [%] = 30
4942 0 VIA2_W_1 Fixed VIA2 width = 0.5
4945 0 VIA2_S_1 Minimum VIA2 spacing = 0.45
4950 0 VIA2_E_1 Minimum MET2 enclosure of VIA2 = 0.2
4951 0 R01V2 VIA2 without MET2 is not allowed
4952 0 ERC Warning: Via2 missing metal2
4954 0 M3_W_1  Minimum MET3 width = 0.6
4957 0 M3_S_1 Minimum MET3 spacing = 0.5
4962 0 M3_E_1 Minimum MET3 enclosure of VIA2 = 0.15
5005 0 M3S2 Minimum MET3 to WIDE_MET3 spacing = 0.8 wide wide 
5007 0 M3_S_2 Minimum MET3 to WIDE_MET3 spacing = 0.8 wide small
5009 0 M3_R_1 Minimum density of MET3 area [%] = 30
5011 0 VIA3_W_1 Fixed VIA3 width = 0.5
5014 0 VIA3_S_1 Minimum VIA3 spacing = 0.45
5019 0 VIA3_E_1 Minimum MET3 enclosure of VIA3 = 0.2
5020 0 R01V3 VIA3 without MET3 is not allowed
5021 0 ERC Warning: VIA3 missing met3
5023 0 M4_W_1 Minimum MET4 width = 0.6
5026 0 M4_S_1 Minimum MET4 spacing = 0.6
5031 0 M4_E_1 Minimum MET4 enclosure of VIA3 = 0.15
5074 0 M4_S_2 Minimum MET4 to WIDE_MET4 spacing = 0.8 wide wide
5076 0 M4_S_2 Minimum MET4 to WIDE_MET4 spacing = 0.8 wide small
5077 0 ERC Warning: VIA3 missing met4
5079 0 M4_R_1 Minimum density of MET4 area [%] = 30
5084 0 INFO: illegal diffusion on pad
5086 0 INFO: illegal poly1 on pad
5088 0 INFO: illegal poly2 on pad
5090 0 INFO: illegal contact on pad
5092 0 CBR1 CB_R_1 missing met1
5094 0 CBR1 CB_R_1 missing met2
5096 0 CBR1 CB_R_1 missing met3
5099 0 CBR1 CB_R_1 missing met4
5100 0 ERC Warning: Missing top met4 on Test or Probe pad
5102 0 W1PA Minimum PAD width = 15
5104 0 CB_W_1 Minimum bonding PAD width (85um preferred, 60um on request) = 70
5106 0 CB_W_1_G1 Minimum bonding PAD width (85um preferred, 60um on request) = 70 preferred 85
5109 0 CB_S_1 Minimum PAD spacing = 15
5113 0 CB_E_1 Minimum MET1 enclosure of PAD_ST = 5
5117 0 CB_E_2 Minimum MET2 enclosure of PAD_3OA = 5
5120 0 CB_E_3 Minimum MET3 enclosure of PAD = 5
5123 0 CB_E_4 Minimum MET4 enclosure of PAD = 5
5142 0 CB_E_5 Minimum MET1 enclosure of the nearest PADVIA1 = 3
5185 0 CB_E_5 bad diamond shape of pad via array must have 4 corners
5188 0 CB_E_5 bad diamond shape of pad via array
5189 0 CB_E_7 bad diamond shape of padvia2 array must have 4 corners
5192 0 CB_E_7 bad diamond shape of padvia2 array
5203 0 CB_E_9 bad diamond shape of padvia3 array must have 4 corners
5206 0 CB_E_9 bad diamond shape of padvia3 array
5209 0 CB_E_7 Minimum MET2 enclosure of the nearest PADVIA2 and PADVIA1 = 3 padvia1
5212 0 CB_E_7 Minimum MET2 enclosure of the nearest PADVIA2 and PADVIA1 = 3 padvia2
5215 0 CB_E_9  Minimum MET3 enclosure of the nearest PADVIA3 and PADVIA2 = 3
5218 0 CB_E_9 Minimum MET3 enclosure of the nearest PADVIA3 and PADVIA2 = 3
5221 0 CB_E_11 Minimum MET4 enclosure of the nearest PADVIA3 = 3
5224 0 CB_S_2 Minimum PADVIA1 spacing = 0.8
5227 0 CB_S_3 Minimum PADVIA2 spacing = 0.8
5230 0 CB_S_4 Minimum PADVIA3 spacing = 0.8
5232 0 CB_C_1 Minimum PADVIA2 to PADVIA1 spacing = 0.3
5234 0 CB_C_2 Minimum PADVIA3 to PADVIA2 spacing = 0.3
5236 0 CB_R_2 Minimum ratio of PADVIA1 area to PAD_ST area [%] = 5
5238 0 CB_R_3 Minimum ratio of PADVIA2 area to PAD_ST area [%] = 5
5240 0 CB_R_4 Minimum ratio of PADVIA3 area to PAD_ST area [%] = 5
5241 0 CB_C_1 Illegal pad via stack via1/via2
5242 0 CB_C_2 Illegal pad via stack via2/via3
5247 0 S1DFPA Minimum PAD_ST to DIFF spacing = 9
5249 0 S1P1PA Minimum PAD_ST to POLY1 spacing = 9
5251 0 S1P2PA Minimum PAD_ST to POLY2 spacing = 9
5254 0 S1M1PA Minimum PAD_ST to MET1 spacing (different net) = 9
5257 0 S1M2PA Minimum PAD_ST to MET2 spacing (different net) = 9
5260 0 S1M3PA Minimum PAD_ST to MET3 spacing (different net) = 9
5263 0 S1M4PA Minimum PAD_ST to MET4 spacing (different net) = 9
5264 0 R01PA PAD without MET4 is not allowed
5265 0 TOPOLOGY PROBLEM : POA pad met 4 stack found, but totally enclosed by MET1
5268 0 Illegal POA pad met3 stack for 4 metal process
5270 0 TOPOLOGY PROBLEM : POA pad met 4 stack found, but totally enclosed by MET2
5272 0 CB_W_1_G1 Minimum bonding PAD width (85um preferred, 60um on request) = 70 Min bonding pad width 70 U, 85 U preferred, 60 U request
5274 0 CB_W_1_G1 Minimum bonding PAD width (85um preferred, 60um on request) = 70 Min bonding pad width 70 U, 85 U preferred, 60 U request
5276 0 CB_W_1_G1 Minimum bonding PAD width (85um preferred, 60um on request) = 70 Min bonding pad width 70 U, 85 U preferred, 60 U request
5277 0 PAR006 : PAD_4OA overlapping VIA2 is not allowed
5280 0 S2PAV2 : Minimum PAD_4OA to VIA2 spacing = 0.5
5283 0 S1PAV3 : Minimum PAD_4OA to VIA3 spacing = 0.25
5287 0 E1PAV3 Minimum PAD_4OA enclosure of VIA3 = 0.2
5295 0 PAR007 : (PAD_4OA sized by -0.7) overlapping VIA3 is not allowed
5297 0 PAR002 KEPOUT definition : (PAD_4OA AND KEPOUT) is not allowed
5300 0 S2KOPA KEPOUT definition : Minimum spacing PAD_4OA to (KEPOUT or SFCDEF) = 7
5306 0 S2M3PA Minimum PAD_4OA to MET3 spacing (different net) = 7
5309 0 S2M4PA Minimum PAD_4OA to MET4 spacing (different net) = 7
5310 0 PAR010 : PAD_OA overlapping CPOLY is not allowed
5361 0 PAR008 Density : Line-of-sight looking through all VIA3 rows at any angle must be blocked by at least one VIA3,via3 density probably too small for this rule
5390 0 PAR008 Density : use 1 row of via3 at min ovlp of PAD poa
5408 0 PAR008 : Line-of-sight looking through all VIA3 rows at any angle must be blocked by at least one VIA3
5454 0 PAR009 :  LV_GATE L > 0.5 PAD_OA overlapping GATE is not allowed,  No valid exemption for LV_GATE, L > 0.5
5460 0 PAR009 : LV_GATE L=LMIN W < 400  PAD_OA overlapping GATE is not allowed, No valid exemption for LV_GATE, L <= 0.5, but total W < 400 U
5493 0  PAR009 : NMOS30M/NMOS18T  L > LMIN  PAD_OA overlapping GATE is not allowed,  No valid exemption for HV_GATE, L > 0.5 LMIN
5508 0 PAR009 : NMOS30M/NMOS18T  L=LMIN W < 400 PAD_OA overlapping GATE is not allowed, No valid exemption for HV_GATE, L <= 0.5 LMIN, but total W < 400 U
5536 0 PAR009 : NMOSH  L > LMIN  PAD_OA overlapping NMOSH_GATE is not allowed,  No valid exemption for NMOSH GATE, L > 3.0
5542 0 PAR009 : NMOSH  L = LMIN < 400 PAD_OA overlapping NMOSH_GATE is not allowed, No valid exemption for NMOSH__GATE, L <= 3.0, but total W < 400 U
5560 0 PAR009: PAD_4OA overlapping GATE is not allowed,  Exemptions : HV_GATE  with HVDEF text ESD*/ LV_GATE L <= 0.5, total active trans W >= 400/ HV_GATE L = MIN, total active trans W >= 400 / LV_GATE overlapping holed POLY1 ..waffel trans
5562 0 W1HR Minimum HRES width = 0.6
5565 0 S1HRHR Minimum HRES spacing = 0.6
5566 0 BAD1HR HRES is not allowed over DIFF
5567 0 BAD2HR HRES is not allowed over NPLUS
5568 0 BAD3HR HRES is not allowed over POLY1
5572 0 E1HRP2 Minimum HRES enclosure of POLY2 = 3
5574 0 S1HRP1 Minimum HRES to POLY1 spacing = 0.35
5576 0 S1HRP2 Minimum HRES to POLY2 spacing = 3
5578 0 S1DFHR  Minimum HRES to DIFF spacing = 0.35
5580 0 W1LV Minimum LVTDEF width = 0.6
5583 0 S1LVLV Minimum LVTDEF spacing = 0.6
5590 0 E1LVAA Minimum LVTDEF enclosure of DIFF = 0.25
5592 0 S1AALV Minimum LVTDEF to DIFF spacing = 0.35
5593 0 LVR001 LVTDEF over ZENER is not allowed
5595 0 LVR002 LVTDEF outside GATE is not allowed
5596 0 LVR003: LVTA outside SFCDEF will be removed and regenerated
5597 0 LFR001: LVPTUB outside SFCDEF will be removed and regenerated
5603 0 NMOSML_R1 Minimum GATE length of NMOSML = 0.5
5609 0 PMOSML_R1 Minimum GATE length of PMOSML = 0.5
5610 0 INFO : metcap not inside met2
5613 0 W1MC Minimum METCAP width = 4
5616 0 W2MC Minimum dummy METCAP width = 0.5
5626 0 W3MC Maximum METCAP size = 30
5627 0 W1M2  Maximum MET2 width (capacitor bottom plate ) = 35
5630 0 S1MCMC Minimum METCAP spacing = 0.8
5632 0 S1M2M2 Minimum MET2 spacing (capacitor bottom plate) = 0.8
5636 0 S1MCV1 Minimum spacing between VIA1 and METCAP = 0.5
5640 0 S1MCV2 Minimum spacing between VIA2 and METCAP = 0.5
5645 0 S1V2V2  Minimum VIA2 spacing on MET2 bottom plate outside METCAP = 4
5649 0 S2V2V2  Minimum VIA2 spacing on METCAP = 3.5
5654 0 E1M2MC Minimum MET2 enclosure of METCAP = 1
5665 0 E1M2V1 Minimum MET2 enclosure of VIA1 (capacitor bottom plate) = 0.2
5668 0 E1M2V2 Minimum MET2 enclosure of VIA2 (capacitor bottom plate) = 0.2
5672 0 E1MCV2 Minimum METCAP enclosure of VIA2 = 0.5
5674 0 R1MC Minimum METCAP density [%] = 3
5677 0 R1V2 Minimum VIA2 density inside METCAP [%] = 1
5678 0 BAD1M1 MET1 under METCAP region is not allowed
5693 0 CMIM_G1: cmim device over active or passive device not allowed
5694 0 CPOLY_G1 PPLUS on CPOLY is not allowed
5695 0 CPOLY_G2 NPLUS on CPOLY is not allowed
5696 0 RPOLY1_R1 PPLUS on RPOLY1 is not allowed
5697 0 RPOLY1_R2 NPLUS on RPOLY1 is not allowed
5698 0 RPOLY2_R1 PPLUS on RPOLY2 is not allowed
5699 0 RPOLY2_R2 NPLUS on RPOLY2 is not allowed
5700 0 RPOLY2P_R1 PPLUS on RPOLY2P is not allowed
5701 0 RPOLY2P_R2 NPLUS on RPOLY2P is not allowed
5702 0 RPOLY2PH_R1 PPLUS on RPOLY2PH is not allowed
5703 0 RPOLY2PH_R2 NPLUS on RPOLY2PH is not allowed
5706 0 E1IPCT Minimum PPLUS enclosure of POLY2CON = 0.6
5707 0 E1IPCT Minimum PPLUS enclosure of POLY2CON = 0.6 missing pplus
5716 0 S1IPP2 Minimum PPLUS to RPOLYH spacing = 0.35
5718 0 RPOLYH_G2 Minimum high precision RPOLYH width = 2
5720 0 W4P2 Minimum RPOLYZ width = 0.8
5723 0 S4P2P2 Minimum RPOLYZ spacing = 0.75
5725 0 S4P2P2 Minimum RPOLYZ spacing = 0.75 notch
5728 0 E2IPCT Minimum PPLUS enclosure of POLY2CON = 0.6
5729 0 E2IPCT Minimum PPLUS enclosure of POLY2CON = 0.6 missing pplus
5738 0 S2IPP2 Minimum PPLUS to RPOLYZ spacing = 0.35
5740 0 RPOLYZ_G2 Minimum high precision RPOLYZ width = 2
6078 0 AMW0 Maximum METx width = 35 metal1
6080 0 AMW0 Maximum METx width = 35 metal2
6082 0 AMW0 Maximum METx width = 35 metal3
6084 0 AMW0 Maximum METx width = 35 metal4
6086 0 AMW1 Fixed slot width = 3 metal1
6089 0 AMW1 Fixed slot width = 3  metal1toolarge
6091 0 AMW1 Fixed slot width = 3 metal2
6094 0 AMW1 Fixed slot width = 3  metal2toolarge
6096 0 AMW1 Fixed slot width = 3 metal3
6099 0 AMW1 Fixed slot width = 3  metal3toolarge
6101 0 AMW1 Fixed slot width = 3 metal4
6104 0 AMW1 Fixed slot width = 3  metal4toolarge
6106 0 AML1 AM_L_2 Minimum slot length = 30 Maximum slot length = 300 metal1
6108 0 AML1 AM_L_2 Minimum slot length = 30 Maximum slot length = 300 metal2
6110 0 AML1 AM_L_2 Minimum slot length = 30 Maximum slot length = 300 metal3
6112 0 AML1 AM_L_2 Minimum slot length = 30 Maximum slot length = 300 metal4
6115 0 AMS1 Minimum spacing between two parallel slots = 10 metal1
6118 0 AMS1 Minimum spacing between two parallel slots = 10 metal2
6121 0 AMS1 Minimum spacing between two parallel slots = 10 metal3
6124 0 AMS1 Minimum spacing between two parallel slots = 10 metal4
6126 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met1 met2 
6128 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met2 met3 
6129 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met1 met2 overlap 
6130 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met2 met3 overlap 
6132 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met3 met4 
6133 0 AMC1 Minimum slots spacing between neighbour layers  = 2 met3 met4 overlap 
6136 0 AMC2 AMC3 Minimum slot to inner metal edge spacing = 10 metal1
6139 0 AMC2 AMC3 Minimum slot to inner metal edge spacing = 10 metal2
6142 0 AMC2 AMC3 Minimum slot to inner metal edge spacing = 10 metal3
6145 0 AMC2 AMC3 Minimum slot to inner metal edge spacing = 10 metal4
6146 0 AM ERROR BAD SLOT: met1 slot outside met1
6147 0 AM ERROR BAD SLOT: met2 slot outside met2
6148 0 AM ERROR BAD SLOT: met3 slot outside met3
6149 0 AM ERROR BAD SLOT: met1 slot over cont
6150 0 AM ERROR BAD SLOT: met1 slot over via1
6151 0 AM ERROR BAD SLOT: met2 slot over via1
6152 0 AM ERROR BAD SLOT: met2 slot over via2
6153 0 AM ERROR BAD SLOT: met3 slot over via2
6154 0 AM ERROR BAD SLOT: met4 slot outside met4
6155 0 AM ERROR BAD SLOT: met4 slot over via3
6159 0 AMTW1 AMTL1 fixed with of dummy MTOP thin blocks 2.0 x 5.0 U
6161 0 AMTS2  Minimum MTOP feature to dummy MTOP block spacing = 2
6848 0 AMTS1 Maximum MTOP spacing when the width of one or both MTOP shapes is less than 10um = 10
6953 0 AMTS3 maximum met4 to met4 block spacing
6956 0  AMTS4 fixed met4 block spacing (checked min only 2.0 U)
6958 0 NWR001 NTUB overlapping KEPOUT is not allowed
6960 0 S1KONW Minimum NTUB spacing to KEPOUT or SFCDEF = 3
6961 0 AAR001 DIFF overlapping KEPOUT is not allowed
6963 0 S1AAKO Minimum DIFF spacing to KEPOUT or SFCDEF = 0.6
6964 0 XMR002 MIDOX overlapping KEPOUT is not allowed
6966 0 S1KOXM Minimum MIDOX spacing to KEPOUT or SFCDEF = 0.6
6967 0 P1R002 POLY1 overlapping KEPOUT is not allowed
6969 0 S1KOP1 Minimum POLY1 spacing to KEPOUT or SFCDEF = 0.45
6970 0 NSR001 NPLUS overlapping KEPOUT is not allowed
6972 0 S1KONS Minimum NPLUS spacing to KEPOUT or SFCDEF = 0.6
6973 0 PSR001 PPLUS overlapping KEPOUT is not allowed
6975 0 S1KOPS Minimum PPLUS spacing to KEPOUT or SFCDEF = 0.6
6976 0 HRR004 HRES overlapping KEPOUT is not allowed
6978 0 S1HRKO Minimum HRES spacing to KEPOUT or SFCDEF = 0.6
6979 0 P2R002 POLY2 overlapping KEPOUT is not allowed
6981 0 S1KOP2 Minimum POLY2 spacing to KEPOUT or SFCDEF = 0.6
6982 0 COR002 CONT overlapping KEPOUT is not allowed
6984 0 S1COKO Minimum CONT spacing to KEPOUT or SFCDEF = 0.4
6985 0 M1R002 MET1 overlapping KEPOUT is not allowed
6987 0 S1KOM1 Minimum MET1 spacing to KEPOUT or SFCDEF = 0.45
6988 0 V1R002 VIA1 overlapping KEPOUT is not allowed
6990 0 S1KOV1 Minimum VIA1 spacing to KEPOUT or SFCDEF = 0.45
6991 0 M2R002 MET2 overlapping KEPOUT is not allowed
6993 0 S1KOM2 0.5
6994 0 V2R002 VIA2 overlapping KEPOUT is not allowed
6996 0 S1KOV2 Minimum VIA2 spacing to KEPOUT or SFCDEF = 0.45
6997 0 M3R002 MET3 overlapping KEPOUT is not allowed
6999 0 S1KOM3 Minimum MET3 spacing to KEPOUT or SFCDEF = 0.6
7000 0 PAR002 PAD overlapping KEPOUT is not allowed
7002 0 S1KOPA Minimum PAD spacing to KEPOUT or SFCDEF (not shown) = 9
7003 0 LVR004 LVTDEF overlapping KEPOUT is not allowed
7005 0 S1KOLV Minimum LVTDEF spacing to KEPOUT or SFCDEF = 0.6
7006 0 MCR002 METCAP overlapping KEPOUT is not allowed
7008 0 S1MCKO Minimum METCAP spacing to KEPOUT or SFCDEF = 0.8
7009 0 V3R002 VIA3 overlapping KEPOUT is not allowed
7011 0 S1KOV3 Minimum VIA3 spacing to KEPOUT or SFCDEF = 0.45
7012 0 M4R002 MET4 overlapping KEPOUT is not allowed
7014 0 S1KOM4 Minimum MET4 spacing to KEPOUT or SFCDEF = 0.6
7017 0 Recommendation: Fixed RESTRM enclosure of RESDEF edge 0.1
7020 0 Recommendation: Fixed RESTRM enclosure of TUBDEF edge 0.1
7025 0 Warning: Illegal Layout Convention: RESDEF/TUBDEF missing RESTRM
7028 0 Warning: Illegal Layout Convention: RESTRM missing RESDEF
7030 0 ERC Warning: DIFF without any contact
7031 0 ERC Warning: Floating Poly1
7032 0 ERC Warning: Floating Poly2
7033 0 ERC Warning: Floating met1
7034 0 ERC Warning: Floating met2
7035 0 ERC Warning: Floating met3
7036 0 ERC Warning: Floating met4
7043 0 ERC Warning: possible Z Diode
7046 0 ERC Warning: Gates connected to VDD/VCC
7047 0 ERC Warning: Gates connected to VSS/GND
7088 0 ERC Warning: floating gate not connected to s/d, pad or resistor
7157 0 ERC Warning: Distance well taps > 50
7159 0 ERC Warning: illegal contact covering poly2 resistor
7161 0 ERC Warning: illegal contact covering poly2p resistor
7163 0 ERC Warning: illegal contact covering poly2ph resistor
7165 0 ERC Warning: illegal contact covering net_ndiff resistor
7167 0 ERC Warning: illegal contact covering net_pdiff resistor
7168 0 ERC Warning: illegal contact covering rpolyh resistor
7169 0 ERC Warning: illegal contact covering rpolyz resistor
7171 0 ERC Warning: illegal contact covering nwell resistor
7178 0 ERC Warning: illegal POLY2 touching rpoly2 resistor outside or bad cut layer
7179 0 ERC Warning: illegal poly2cut touching rpolyh resistor
7180 0 ERC Warning: illegal poly2cut touching rpolyz resistor
7184 0 ERC Warning: illegal NTUB touching rnwell resistor outside
7190 0 ERC Warning: illegal net_pdiff touching rdiffp resistor outside
7196 0 ERC Warning: illegal net_ndiff touching rdiffn resistor outside
7341 0 ERC Warning: Latchup rule LAT3 distance s/d diff ngate net_subtap > 20
7473 0 ERC Warning: Latchup rule LAT3 distance s/d diff pgate net_welltap > 20
7475 0 PWR001: FIMP outside SFCDEF will be removed and regenerated
7477 0 LDR001: NLDD outside SFCDEF will be removed and regenerated
7479 0  L2R001: NLDD50 outside SFCDEF will be removed and regenerated
7480 0 PYR001 PCOAT outside SFCDEF will be removed and regenerated
7482 0 Minimum PCOAT width = 15
7485 0 Minimum PCOAT spacing = 15
7486 0 REC002 PCOAT not multiple 45 degrees PCOAT
7489 0 W1BK Minimum PCOAT_black width = 2
7492 0 S1BKBK Minimum PCOAT_black spacing = 2.0
7494 0 S1BKPA Minimum PCOAT_blackto PAD spacing = 3.0
7497 0 S1BKSB Minimum PCOAT_black to CHIPEDGE spacing = 20.0
7500 0 W1CR Minimum PCOAT_clear width = 2
7503 0 S1CRCR Minimum PCOAT_clear spacing = 2.0
7505 0 S1CRPA Minimum PCOAT_clear to PAD spacing = 3.0
7508 0 S1CRSB Minimum PCOAT_clear to CHIPEDGE spacing = 20.0
7511 0 W1GN Minimum PCOAT_green width = 2
7514 0 S1GNGN Minimum PCOAT_green spacing = 2.0
7516 0 S1GNPA Minimum PCOAT_greento PAD spacing = 3.0
7519 0 S1GNSB Minimum PCOAT_green to CHIPEDGE spacing = 20.0
7522 0 W1RD Minimum PCOAT_red width = 2
7525 0 S1RDRD Minimum PCOAT_red spacing = 2.0
7527 0 S1PARD Minimum PCOAT_red to PAD spacing = 3.0
7530 0 S1RDSB Minimum PCOAT_red to CHIPEDGE spacing = 20.0
7533 0 W1BU Minimum PCOAT_blue width = 2
7536 0 S1BUBU Minimum PCOAT_blue spacing = 2.0
7538 0 S1BUPA Minimum PCOAT_blue to PAD spacing = 3.0
7541 0 S1BUSB Minimum PCOAT_blue to CHIPEDGE spacing = 20.0
7547 0 BAD_PDIFF_MULTCONN_ERC
7552 0 BAD_NDIFF_MULTCONN_ERC
7559 0 AR1_error_gate: AR1: Maximum ratio of floating POLY1 edge area to connected GATE area = 200
7561 0 AR2_error_gate: AR2: Maximum ratio of floating MET1 edge area to connected GATE area = 400
7563 0 AR3_error_gate: AR3: Maximum ratio of floating MET2 edge area to connected GATE area = 400
7565 0 AR4_error_gate: AR4: Maximum ratio of floating MET3 edge area to connected GATE area = 400
7567 0 AR5_error_gate: AR5: Maximum ratio of floating MET4 edge area to connected GATE area = 400
7568 0 rpoly1_g1_pres1_wexp: RPOLY1_G1: Minimum number of RPOLY1 squares = 5
7569 0 rpoly2_g1_pres_wexp: RPOLY2_G1: Minimum number of RPOLY2 squares = 5
7570 0 rpoly2p_g1_presp_wexp: RPOLY2P_G1: Minimum number of RPOLY2P squares = 5
7571 0 rpoly2ph_g1_presph_wexp: RPOLY2PH_G1: Minimum number of RPOLY2PH squares = 5
7572 0 rnwell_g1_nwres_wexp: RNWELL_G1: Minimum number of RNWELL squares = 5
7573 0 rpolyh_g1_presh_wexp: RPOLYH_G1: Minimum number of RPOLYH squares = 5
7574 0 rpolyh_g1_presz_wexp: RPOLYZ_G1: Minimum number of RPOLYZ squares = 3.75
7575 0 G01P1_net_poly1con: G01P1 Maximum ratio of POLY2 area to connected CONT area = 18000
7576 0 G01P2_net_poly2con: G01P2 Maximum ratio of POLY2 area to connected CONT area = 22000
7584 0 CBR1 PAD met2 not connected to met1
7585 0 CBR1 PAD met3 not connected to met2
7586 0 CBR1 PAD met4 not connected to met3
7588 0 ERC Warning: Internal spiral met3 short
7590 0 ERC Warning: Internal spiral met2 short
7594 0 ERC Warning: spiral may be shorted by external met2
7598 0 ERC Warning: spiral may be shorted by external met3
7600 0 ERC Warning: Internal spiral met4 short
7604 0 ERC Warning: spiral may be shorted by external met4
7605 0 spiral_open_spiral_term22: ERC Warning : This spiral is open
7606 0 # INFO: C35B4/C35B3 ASSURA DRC DECK (REV9 DATE 26-Apr-2011) Last modified 29-Oct-2013 #
