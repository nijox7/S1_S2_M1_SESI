0	net2
0	V0:p
0	V1:p
0	Vout
0	vdd!
