#Compte-rendu TP2

## Point de fonctionnement
On a un offset de 0.005 v soit 5 mv de décalage de la tension d'entrée pour une tension de sortie de 1.65v. Soit Vout = 1.65V pour Vindc = 1.645V.

##

