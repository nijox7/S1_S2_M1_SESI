#Compte-rendu TP1

##7.3

La tension de sortie est égale au gain
